import { BonkDashboard } from "@/components/bonk-dashboard"

export default function Home() {
  return <BonkDashboard />
}
