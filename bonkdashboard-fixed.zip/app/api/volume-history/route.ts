import { NextResponse } from "next/server"

const USD1_MINT = "USD1ttGY1N17NEEHLmELoaybftRBUSErhqYiQzvEmuB"
const BITQUERY_API = "https://streaming.bitquery.io/graphql"

// Cache for volume history
interface VolumeDataPoint {
  timestamp: number
  volume: number
  trades: number
}

interface CacheEntry {
  data: VolumeDataPoint[]
  timestamp: number
  period: string
  synthetic: boolean
}

let volumeCache: Map<string, CacheEntry> = new Map()
const CACHE_TTL = 5 * 60 * 1000 // 5 minutes cache

// Calculate date ranges based on period
function getDateRange(period: string): { since: string; until: string; interval: string } {
  const now = new Date()
  const until = now.toISOString()
  
  let since: Date
  let interval: string
  
  switch (period) {
    case "24h":
      since = new Date(now.getTime() - 24 * 60 * 60 * 1000)
      interval = "hour"
      break
    case "7d":
      since = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
      interval = "day" // 1 day candles for 7d view
      break
    case "1m":
      since = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
      interval = "day"
      break
    case "all":
      // USD1 launched around early 2025 - set to a reasonable start date
      since = new Date("2025-01-01T00:00:00Z")
      interval = "month" // 1 month candles for all time view
      break
    default:
      since = new Date(now.getTime() - 24 * 60 * 60 * 1000)
      interval = "hour"
  }
  
  return { since: since.toISOString(), until, interval }
}

// Fetch volume data from Bitquery
async function fetchBitqueryVolume(period: string): Promise<{ data: VolumeDataPoint[]; synthetic: boolean }> {
  const apiKey = process.env.BITQUERY_API_KEY
  
  if (!apiKey) {
    console.error("[Volume] BITQUERY_API_KEY not configured")
    return { data: generateFallbackData(period), synthetic: true }
  }

  const { since, until, interval } = getDateRange(period)
  
  // GraphQL query to get USD1 pair volume on Raydium
  const query = `
    query GetUSD1Volume {
      Solana {
        DEXTradeByTokens(
          where: {
            Trade: {
              Currency: {
                MintAddress: { is: "${USD1_MINT}" }
              }
              Dex: {
                ProtocolFamily: { in: ["Raydium", "Raydium CLMM", "Raydium CPMM"] }
              }
            }
            Block: {
              Time: { since: "${since}", till: "${until}" }
            }
            Transaction: {
              Result: { Success: true }
            }
          }
          orderBy: { ascendingByField: "Block_Time" }
        ) {
          Block {
            Time(interval: { in: ${interval}s })
          }
          volume: sum(of: Trade_Side_AmountInUSD)
          trades: count
        }
      }
    }
  `

  try {
    const response = await fetch(BITQUERY_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ query }),
    })

    if (!response.ok) {
      console.error("[Volume] Bitquery API error:", response.status, await response.text())
      return { data: generateFallbackData(period), synthetic: true }
    }

    const json = await response.json()
    
    if (json.errors) {
      console.error("[Volume] Bitquery query errors:", json.errors)
      return { data: generateFallbackData(period), synthetic: true }
    }

    const trades = json.data?.Solana?.DEXTradeByTokens || []
    
    if (trades.length === 0) {
      console.log("[Volume] No trade data returned from Bitquery")
      return { data: generateFallbackData(period), synthetic: true }
    }

    // Transform the data
    const volumeData: VolumeDataPoint[] = trades.map((trade: any) => ({
      timestamp: new Date(trade.Block.Time).getTime(),
      volume: parseFloat(trade.volume) || 0,
      trades: parseInt(trade.trades) || 0,
    }))

    // Sort by timestamp
    volumeData.sort((a, b) => a.timestamp - b.timestamp)

    console.log(`[Volume] Fetched ${volumeData.length} data points from Bitquery for period ${period}`)
    
    return { data: volumeData, synthetic: false }
  } catch (error) {
    console.error("[Volume] Error fetching from Bitquery:", error)
    return { data: generateFallbackData(period), synthetic: true }
  }
}

// Generate fallback data based on current metrics when API fails
function generateFallbackData(period: string): VolumeDataPoint[] {
  const now = Date.now()
  const data: VolumeDataPoint[] = []
  
  let points: number
  let intervalMs: number
  
  switch (period) {
    case "24h":
      points = 24
      intervalMs = 60 * 60 * 1000 // 1 hour
      break
    case "7d":
      points = 7
      intervalMs = 24 * 60 * 60 * 1000 // 1 day candles
      break
    case "1m":
      points = 30
      intervalMs = 24 * 60 * 60 * 1000 // 1 day
      break
    case "all":
      // Months since Jan 1, 2025
      const startDate = new Date("2025-01-01").getTime()
      points = Math.ceil((now - startDate) / (30 * 24 * 60 * 60 * 1000)) // 1 month candles
      intervalMs = 30 * 24 * 60 * 60 * 1000 // 1 month
      break
    default:
      points = 24
      intervalMs = 60 * 60 * 1000
  }
  
  // Generate realistic looking data with some variance
  // Base on typical BONK.FUN volume patterns
  const baseVolume = 500000 // Base $500k daily volume
  
  for (let i = points; i >= 0; i--) {
    const timestamp = now - (i * intervalMs)
    const date = new Date(timestamp)
    const hour = date.getHours()
    const dayOfWeek = date.getDay()
    
    // Volume patterns: higher during US trading hours, lower on weekends
    let multiplier = 1
    if (hour >= 14 && hour <= 22) multiplier *= 1.5 // US hours
    else if (hour >= 8 && hour <= 14) multiplier *= 1.2
    else multiplier *= 0.7
    
    if (dayOfWeek === 0 || dayOfWeek === 6) multiplier *= 0.6 // Weekend
    
    // Add growth trend for older data
    const ageDays = (now - timestamp) / (24 * 60 * 60 * 1000)
    const trendMultiplier = Math.max(0.3, 1 - (ageDays * 0.01)) // Older = lower base
    
    // Random variance
    const variance = 0.7 + Math.random() * 0.6
    
    const volume = baseVolume * multiplier * trendMultiplier * variance * (intervalMs / (24 * 60 * 60 * 1000))
    
    data.push({
      timestamp,
      volume: Math.round(volume),
      trades: Math.round(50 + Math.random() * 200),
    })
  }
  
  return data
}

export async function GET(request: Request) {
  const url = new URL(request.url)
  const period = url.searchParams.get("period") || "24h"
  
  // Check cache
  const cached = volumeCache.get(period)
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return NextResponse.json({
      history: cached.data,
      stats: calculateStats(cached.data),
      period,
      dataPoints: cached.data.length,
      cached: true,
      synthetic: cached.synthetic,
    })
  }
  
  // Fetch fresh data
  const { data: volumeData, synthetic } = await fetchBitqueryVolume(period)
  
  // Update cache
  volumeCache.set(period, {
    data: volumeData,
    timestamp: Date.now(),
    period,
    synthetic,
  })
  
  return NextResponse.json({
    history: volumeData,
    stats: calculateStats(volumeData),
    period,
    dataPoints: volumeData.length,
    cached: false,
    synthetic,
  })
}

function calculateStats(data: VolumeDataPoint[]): {
  current: number
  previous: number
  change: number
  peak: number
  low: number
  average: number
  totalVolume: number
} {
  if (data.length === 0) {
    return { current: 0, previous: 0, change: 0, peak: 0, low: 0, average: 0, totalVolume: 0 }
  }
  
  const volumes = data.map(d => d.volume)
  const current = volumes[volumes.length - 1] || 0
  const previous = volumes[0] || current
  const change = previous > 0 ? ((current - previous) / previous) * 100 : 0
  const totalVolume = volumes.reduce((sum, v) => sum + v, 0)
  
  return {
    current,
    previous,
    change,
    peak: Math.max(...volumes),
    low: Math.min(...volumes),
    average: totalVolume / volumes.length,
    totalVolume,
  }
}
